// Import jwt library
const jwt = require('jsonwebtoken');

// Define secret key
const secretKey = 'secret';

// Create a function to generate a token
function generateToken(user) {
  // Create a payload object with the user's data
  const payload = {
    id: user.id,
    name: user.name,
  };

  // Sign the payload with the secret key
  const token = jwt.sign(payload, secretKey);

  // Return the token
  return token;
}

// Create a function to verify a token
function verifyToken(token) {
  // Verify the token with the secret key
  const decoded = jwt.verify(token, secretKey);

  // Return the decoded token
  return decoded;
}

// Export the functions
module.exports = {
  generateToken,
  verifyToken,
};